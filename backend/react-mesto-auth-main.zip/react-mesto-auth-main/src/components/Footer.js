import '../index.css';

function Footer() {
  return (
    <footer className="footer">
    <p className="footer__copyright">© 2021 Mesto Russia</p>
  </footer>
  );
}

export default Footer;