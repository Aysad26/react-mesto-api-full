import React from 'react';
export const CurrentCardsContext = React.createContext();